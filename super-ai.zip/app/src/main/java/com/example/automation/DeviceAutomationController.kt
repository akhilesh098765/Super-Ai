package com.example.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast

enum class ActionRiskLevel(val label: String, val requiresAuth: Boolean, val colorHex: Long) {
    LOW("Low Risk - Standard Intent", false, 0xFF00E676),
    MEDIUM("Medium Risk - System Navigation", false, 0xFFFFB703),
    HIGH("High Risk - Privileged Automation", true, 0xFFFF3366)
}

data class AutomationAction(
    val id: String,
    val title: String,
    val description: String,
    val riskLevel: ActionRiskLevel,
    val category: String
)

object DeviceAutomationController {

    val availableActions = listOf(
        AutomationAction(
            id = "toggle_wifi_settings",
            title = "Open Wi-Fi Settings",
            description = "Navigate user to Wi-Fi toggles & network configuration",
            riskLevel = ActionRiskLevel.LOW,
            category = "Connectivity"
        ),
        AutomationAction(
            id = "toggle_bluetooth_settings",
            title = "Open Bluetooth Settings",
            description = "Navigate user to Bluetooth pairing & toggles",
            riskLevel = ActionRiskLevel.LOW,
            category = "Connectivity"
        ),
        AutomationAction(
            id = "open_sound_settings",
            title = "Audio & Media Controls",
            description = "Open device audio, volume, and sound preferences",
            riskLevel = ActionRiskLevel.LOW,
            category = "Media"
        ),
        AutomationAction(
            id = "open_accessibility_settings",
            title = "Accessibility Settings",
            description = "Manage Super AI system automation permissions",
            riskLevel = ActionRiskLevel.LOW,
            category = "System"
        ),
        AutomationAction(
            id = "global_notifications",
            title = "Pull Notification Shade",
            description = "Expand device system notifications programmatically",
            riskLevel = ActionRiskLevel.MEDIUM,
            category = "System"
        ),
        AutomationAction(
            id = "global_home",
            title = "Simulate Home Button",
            description = "Return device to home launcher screen",
            riskLevel = ActionRiskLevel.MEDIUM,
            category = "Navigation"
        ),
        AutomationAction(
            id = "dispatch_auto_tap",
            title = "Automated Screen Tap",
            description = "Dispatch simulated touch event at coordinates (X:500, Y:800)",
            riskLevel = ActionRiskLevel.HIGH,
            category = "Actuator"
        ),
        AutomationAction(
            id = "dispatch_auto_swipe",
            title = "Automated Screen Swipe",
            description = "Dispatch upward swipe gesture across device display",
            riskLevel = ActionRiskLevel.HIGH,
            category = "Actuator"
        ),
        AutomationAction(
            id = "launch_calculator",
            title = "Launch Calculator",
            description = "Invoke system math calculator via intent",
            riskLevel = ActionRiskLevel.LOW,
            category = "App Launch"
        ),
        AutomationAction(
            id = "launch_browser",
            title = "Launch Web Browser",
            description = "Open default web browser for research tasks",
            riskLevel = ActionRiskLevel.LOW,
            category = "App Launch"
        )
    )

    fun executeAction(
        context: Context,
        action: AutomationAction,
        onStatus: (String) -> Unit
    ) {
        val a11y = SuperAiAccessibilityService.instance

        when (action.id) {
            "toggle_wifi_settings" -> {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                onStatus("Opened Wi-Fi Settings")
            }

            "toggle_bluetooth_settings" -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                onStatus("Opened Bluetooth Settings")
            }

            "open_sound_settings" -> {
                val intent = Intent(Settings.ACTION_SOUND_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                onStatus("Opened Audio & Sound Settings")
            }

            "open_accessibility_settings" -> {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                onStatus("Opened Accessibility Settings")
            }

            "global_notifications" -> {
                if (a11y != null) {
                    a11y.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
                    onStatus("Expanded Notification Shade via Accessibility Bridge")
                } else {
                    onStatus("Accessibility Service is not enabled. Enable it in Settings first.")
                }
            }

            "global_home" -> {
                if (a11y != null) {
                    a11y.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)
                    onStatus("Executed Home button navigation")
                } else {
                    val intent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    onStatus("Dispatched Intent Home action")
                }
            }

            "dispatch_auto_tap" -> {
                if (a11y != null) {
                    a11y.dispatchTap(500f, 800f) { success ->
                        onStatus(if (success) "Dispatched automated tap at (500, 800) successfully" else "Tap canceled or blocked")
                    }
                } else {
                    onStatus("Accessibility Service required for automated taps. Simulated tap executed in sandbox.")
                }
            }

            "dispatch_auto_swipe" -> {
                if (a11y != null) {
                    a11y.dispatchSwipe(500f, 1200f, 500f, 400f, 300) { success ->
                        onStatus(if (success) "Dispatched automated swipe up successfully" else "Swipe canceled or blocked")
                    }
                } else {
                    onStatus("Accessibility Service required for automated swipe. Simulated gesture recorded in sandbox.")
                }
            }

            "launch_calculator" -> {
                val intent = Intent().apply {
                    setAction(Intent.ACTION_MAIN)
                    addCategory(Intent.CATEGORY_APP_CALCULATOR)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                try {
                    context.startActivity(intent)
                    onStatus("Calculator launched successfully")
                } catch (_: Exception) {
                    onStatus("Calculator intent dispatched (or mock opened)")
                }
            }

            "launch_browser" -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://google.com")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                onStatus("Opened browser session")
            }

            else -> {
                onStatus("Action ${action.title} processed")
            }
        }
    }
}
