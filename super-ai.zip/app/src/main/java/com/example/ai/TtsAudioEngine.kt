package com.example.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsAudioEngine(context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _statusMessage = MutableStateFlow("TTS Engine Ready")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e("TtsAudioEngine", "Failed to init TextToSpeech: ${e.message}")
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                _statusMessage.value = "Language not supported or missing data"
            } else {
                isInitialized = true
                _statusMessage.value = "Google TTS / Voice Synthesis Ready"
            }
        } else {
            _statusMessage.value = "TTS Initialization failed"
        }
    }

    fun speak(text: String, pitch: Float = 1.0f, speed: Float = 1.0f) {
        if (!isInitialized) {
            _statusMessage.value = "TTS not yet initialized"
            return
        }
        tts?.setPitch(pitch)
        tts?.setSpeechRate(speed)
        _isSpeaking.value = true
        _statusMessage.value = "Synthesizing and playing speech..."
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "SuperAiTTS")
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
        _statusMessage.value = "Speech stopped"
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
