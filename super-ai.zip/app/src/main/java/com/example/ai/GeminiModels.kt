package com.example.ai

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

enum class ContentType(val label: String, val promptHint: String) {
    RESEARCH_PAPER("Research Paper", "Write an exhaustive, high-impact scientific research paper complete with Abstract, Methodology, Findings, and Academic Citations on:"),
    BOOK_CHAPTER("Book Chapter", "Draft an engaging, immersive book chapter with vivid narrative, dialogue, and character depth on:"),
    BLOG_POST("Blog Post", "Write an SEO-optimized, highly engaging blog post with catchy subheadings, key takeaways, and call-to-action on:"),
    AD_COPY("Ad Copy", "Craft high-converting ad copy with attention-grabbing hook, emotional pain points, benefits, and urgent CTA on:"),
    EMAIL("Executive Email", "Draft a crisp, persuasive executive business email with strategic tone and clear action items on:"),
    SCRIPT("Video Script", "Write a captivating 60-second video script with visual scene directions and voiceover cues for:"),
    SOCIAL_POST("Social Media Post", "Write high-viral social media posts for Twitter/X, LinkedIn, and Instagram with relevant hashtags for:")
}

enum class ParaphraseTone(val label: String, val instruction: String) {
    PROFESSIONAL("Professional", "Rewrite the text in an authoritative, polished corporate business tone while maintaining clarity."),
    CASUAL("Casual", "Rewrite the text in a friendly, conversational, relatable and relaxed everyday tone."),
    ACADEMIC("Academic", "Rewrite the text using rigorous scholarly vocabulary, formal syntactical structures, and analytical depth."),
    CREATIVE("Creative", "Rewrite the text with rich sensory metaphors, stylistic flair, evocative imagery, and creative storytelling.")
}

data class PlagiarismSource(
    val title: String,
    val url: String,
    val similarityPercentage: Int,
    val matchedSnippet: String
)

data class PlagiarismAnalysisResult(
    val originalityScore: Int, // e.g. 94%
    val aiProbabilityScore: Int, // e.g. 8%
    val wordCount: Int,
    val status: String,
    val sources: List<PlagiarismSource>,
    val highlights: List<String>
)

data class VoiceProfile(
    val id: String,
    val name: String,
    val gender: String,
    val provider: String,
    val previewTone: String
)

data class GeneratedScene(
    val sceneNumber: Int,
    val timestamp: String,
    val visualDescription: String,
    val cameraMovement: String,
    val audioPrompt: String
)

// Gemini REST Data Classes for Moshi
@JsonClass(generateAdapter = true)
data class GeminiRequest(
    @Json(name = "contents") val contents: List<GeminiContent>
)

@JsonClass(generateAdapter = true)
data class GeminiContent(
    @Json(name = "parts") val parts: List<GeminiPart>
)

@JsonClass(generateAdapter = true)
data class GeminiPart(
    @Json(name = "text") val text: String
)

@JsonClass(generateAdapter = true)
data class GeminiResponse(
    @Json(name = "candidates") val candidates: List<GeminiCandidate>?
)

@JsonClass(generateAdapter = true)
data class GeminiCandidate(
    @Json(name = "content") val content: GeminiContent?
)
