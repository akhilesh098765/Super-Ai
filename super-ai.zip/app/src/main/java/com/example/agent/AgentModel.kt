package com.example.agent

enum class AgentRole(val displayName: String, val badgeColorHex: Long) {
    DIRECTOR("Director Agent (CrewAI Lead)", 0xFF00F0FF),
    RESEARCHER("Research Agent (LangChain Retriever)", 0xFF3A86FF),
    CRITIC("Critic & Safety Agent (Self-Reflection)", 0xFFFFB703),
    EXECUTOR("Executor Agent (Device Actuator)", 0xFF00E676)
}

enum class TaskStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED
}

data class SubTask(
    val id: String,
    val title: String,
    val role: AgentRole,
    var status: TaskStatus = TaskStatus.PENDING,
    val toolName: String,
    val inputDescription: String,
    var outputResult: String = "",
    var reflectionNote: String = ""
)

data class AgentExecutionState(
    val originalGoal: String,
    val tasks: List<SubTask>,
    val activeTaskIndex: Int,
    val isRunning: Boolean,
    val finalSynthesis: String = "",
    val selfReflectionCritique: String = ""
)
