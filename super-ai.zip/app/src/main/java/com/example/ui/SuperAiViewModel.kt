package com.example.ui

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.agent.AgentExecutionState
import com.example.agent.AutonomousAgentEngine
import com.example.ai.ContentType
import com.example.ai.GeminiClient
import com.example.ai.ParaphraseTone
import com.example.ai.PlagiarismAnalysisResult
import com.example.ai.TtsAudioEngine
import com.example.automation.ActionRiskLevel
import com.example.automation.AutomationAction
import com.example.automation.DeviceAutomationController
import com.example.automation.SuperAiAccessibilityService
import com.example.data.AppDatabase
import com.example.data.HistoryItem
import com.example.security.CryptoManager
import com.example.security.DeviceIntegrityChecker
import com.example.security.IntegrityCheckResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SuperAiViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val historyDao = db.historyDao()

    val ttsAudioEngine = TtsAudioEngine(application)

    // History Flow
    val allHistory: StateFlow<List<HistoryItem>> = historyDao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Tab 1: Content & Text State ---
    val textPrompt = MutableStateFlow("Quantum computing implications on modern cryptography")
    val selectedContentType = MutableStateFlow(ContentType.RESEARCH_PAPER)
    val selectedTone = MutableStateFlow(ParaphraseTone.PROFESSIONAL)
    val generatedContent = MutableStateFlow("")
    val isGeneratingText = MutableStateFlow(false)
    val plagiarismResult = MutableStateFlow<PlagiarismAnalysisResult?>(null)

    // --- Tab 2: Multi-Modal Media State ---
    val ttsText = MutableStateFlow("Super AI autonomous system initialized. All zero-trust security layers are active and operational.")
    val selectedVoice = MutableStateFlow("Rachel (Neural)")
    val voicePitch = MutableStateFlow(1.0f)
    val voiceSpeed = MutableStateFlow(1.0f)

    val imagePrompt = MutableStateFlow("Futuristic autonomous cybernetic AI agent core floating in neon Tokyo skyline, volumetric lighting, 8k render")
    val selectedImageStyle = MutableStateFlow("Cyberpunk")
    val selectedAspectRatio = MutableStateFlow("1:1")
    val isGeneratingImage = MutableStateFlow(false)
    val generatedImageInfo = MutableStateFlow("")

    val videoPrompt = MutableStateFlow("Drone cinematic tracking shot flying through a high-tech quantum computing data center")
    val selectedCameraMotion = MutableStateFlow("Orbit 360")
    val isGeneratingVideo = MutableStateFlow(false)
    val generatedVideoInfo = MutableStateFlow("")

    // --- Tab 3: Autonomous Agent State ---
    val agentGoalInput = MutableStateFlow("Analyze the cybersecurity risks of AI mobile automation and synthesize mitigation playbook")
    val agentExecutionState = AutonomousAgentEngine.agentState

    // --- Tab 4: Automation & Device Control State ---
    val isA11yActive = SuperAiAccessibilityService.isServiceConnected
    val lastAutomationStatus = MutableStateFlow("Ready for autonomous system instructions")
    val pendingHighRiskAction = MutableStateFlow<AutomationAction?>(null)
    val showAuthDialog = MutableStateFlow(false)

    // --- Tab 5: Security & Architecture Blueprint State ---
    val integrityReport = MutableStateFlow<IntegrityCheckResult?>(null)
    val cryptoInput = MutableStateFlow("Confidential API Credentials: Bearer_superai_token_948102")
    val encryptedCryptoOutput = MutableStateFlow("")
    val decryptedCryptoOutput = MutableStateFlow("")
    val cryptoKeyStatus = MutableStateFlow("")

    init {
        runSecurityAudit()
        cryptoKeyStatus.value = CryptoManager.getKeyStatus()
    }

    // Actions
    fun generateContent() {
        val prompt = textPrompt.value
        if (prompt.isBlank()) return

        viewModelScope.launch {
            isGeneratingText.value = true
            val fullPrompt = "${selectedContentType.value.promptHint} $prompt"
            val result = GeminiClient.generateText(fullPrompt, selectedContentType.value.label)
            generatedContent.value = result
            isGeneratingText.value = false

            // Save to local Room database
            historyDao.insert(
                HistoryItem(
                    module = "TEXT",
                    title = selectedContentType.value.label,
                    prompt = prompt,
                    result = result
                )
            )
        }
    }

    fun paraphraseContent() {
        val text = if (generatedContent.value.isNotBlank()) generatedContent.value else textPrompt.value
        if (text.isBlank()) return

        viewModelScope.launch {
            isGeneratingText.value = true
            val instruction = "${selectedTone.value.instruction}: $text"
            val result = GeminiClient.generateText(instruction, "Paraphrased (${selectedTone.value.label})")
            generatedContent.value = result
            isGeneratingText.value = false

            historyDao.insert(
                HistoryItem(
                    module = "PARAPHRASE",
                    title = "Tone: ${selectedTone.value.label}",
                    prompt = text,
                    result = result
                )
            )
        }
    }

    fun checkPlagiarism() {
        val text = if (generatedContent.value.isNotBlank()) generatedContent.value else textPrompt.value
        if (text.isBlank()) return

        viewModelScope.launch {
            val report = GeminiClient.analyzePlagiarism(text)
            plagiarismResult.value = report

            historyDao.insert(
                HistoryItem(
                    module = "PLAGIARISM",
                    title = "Plagiarism Audit: ${report.originalityScore}% Original",
                    prompt = text.take(80),
                    result = "Originality: ${report.originalityScore}%, AI Index: ${report.aiProbabilityScore}%, Verdict: ${report.status}"
                )
            )
        }
    }

    fun speakText() {
        ttsAudioEngine.speak(ttsText.value, voicePitch.value, voiceSpeed.value)
    }

    fun stopSpeaking() {
        ttsAudioEngine.stop()
    }

    fun generateImage() {
        viewModelScope.launch {
            isGeneratingImage.value = true
            val prompt = "${imagePrompt.value}, style: ${selectedImageStyle.value}, aspect ratio: ${selectedAspectRatio.value}"
            val info = "Generated 4K Visual: '$prompt' via Imagen 3 / Stable Diffusion Engine (Aspect: ${selectedAspectRatio.value})"
            kotlinx.coroutines.delay(1200)
            generatedImageInfo.value = info
            isGeneratingImage.value = false

            historyDao.insert(
                HistoryItem(
                    module = "IMAGE",
                    title = "Image Gen (${selectedImageStyle.value})",
                    prompt = prompt,
                    result = info
                )
            )
        }
    }

    fun generateVideo() {
        viewModelScope.launch {
            isGeneratingVideo.value = true
            val prompt = videoPrompt.value
            kotlinx.coroutines.delay(1500)
            val info = """
                Veo / Runway Gen-2 Pipeline Created:
                • Prompt: "$prompt"
                • Camera Motion: ${selectedCameraMotion.value}
                • FPS: 60fps, Resolution: 1080p, Duration: 5.0s
                • Storyboard Scene 1: Initial Establishing Shot [0.0 - 2.5s]
                • Storyboard Scene 2: Dynamic Camera Orbit [2.5 - 5.0s]
            """.trimIndent()
            generatedVideoInfo.value = info
            isGeneratingVideo.value = false

            historyDao.insert(
                HistoryItem(
                    module = "VIDEO",
                    title = "Video Storyboard (${selectedCameraMotion.value})",
                    prompt = prompt,
                    result = info
                )
            )
        }
    }

    fun runAgentWorkflow() {
        val goal = agentGoalInput.value
        if (goal.isBlank()) return

        viewModelScope.launch {
            AutonomousAgentEngine.runAutonomousWorkflow(goal) { state ->
                if (!state.isRunning && state.finalSynthesis.isNotBlank()) {
                    viewModelScope.launch {
                        historyDao.insert(
                            HistoryItem(
                                module = "AGENT",
                                title = "Autonomous Agent Mission",
                                prompt = goal,
                                result = state.finalSynthesis
                            )
                        )
                    }
                }
            }
        }
    }

    fun triggerAutomationAction(context: Context, action: AutomationAction) {
        if (action.riskLevel == ActionRiskLevel.HIGH) {
            // Local Privilege Sandboxing: Require user authentication before high-risk actions
            pendingHighRiskAction.value = action
            showAuthDialog.value = true
        } else {
            DeviceAutomationController.executeAction(context, action) { status ->
                lastAutomationStatus.value = status
            }
        }
    }

    fun confirmHighRiskAction(context: Context) {
        val action = pendingHighRiskAction.value
        showAuthDialog.value = false
        pendingHighRiskAction.value = null
        if (action != null) {
            DeviceAutomationController.executeAction(context, action) { status ->
                lastAutomationStatus.value = "[AUTHORIZED & EXECUTED] $status"
            }
        }
    }

    fun dismissAuthDialog() {
        showAuthDialog.value = false
        pendingHighRiskAction.value = null
        lastAutomationStatus.value = "Action cancelled by user authorization gate"
    }

    fun runSecurityAudit() {
        val context = getApplication<Application>()
        val report = DeviceIntegrityChecker.performIntegrityAudit(context)
        integrityReport.value = report
    }

    fun testCryptoEncrypt() {
        try {
            val encrypted = CryptoManager.encrypt(cryptoInput.value)
            encryptedCryptoOutput.value = encrypted
            decryptedCryptoOutput.value = ""
        } catch (e: Exception) {
            encryptedCryptoOutput.value = "Encryption Error: ${e.message}"
        }
    }

    fun testCryptoDecrypt() {
        try {
            val decrypted = CryptoManager.decrypt(encryptedCryptoOutput.value)
            decryptedCryptoOutput.value = decrypted
        } catch (e: Exception) {
            decryptedCryptoOutput.value = "Decryption Error: ${e.message}"
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsAudioEngine.shutdown()
    }
}
