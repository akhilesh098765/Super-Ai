package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.SecurityLevel
import com.example.ui.screens.*
import com.example.ui.theme.*

enum class AppNavDestination(
    val title: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
) {
    TEXT_STUDIO("Text", Icons.Filled.EditNote, Icons.Outlined.EditNote),
    MULTIMODAL("Media", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome),
    AGENTS("Agents", Icons.Filled.Psychology, Icons.Outlined.Psychology),
    AUTOMATION("Device", Icons.Filled.TouchApp, Icons.Outlined.TouchApp),
    SECURITY("Security", Icons.Filled.Shield, Icons.Outlined.Shield)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp(
    viewModel: SuperAiViewModel
) {
    var currentDestination by remember { mutableStateOf(AppNavDestination.TEXT_STUDIO) }
    var showHistoryScreen by remember { mutableStateOf(false) }

    val integrityReport by viewModel.integrityReport.collectAsState()
    val securityLevel = integrityReport?.overallSecurityLevel ?: SecurityLevel.SECURE

    val securityBadgeColor = when (securityLevel) {
        SecurityLevel.SECURE -> SecurityGreen
        SecurityLevel.SUSPICIOUS -> WarningAmber
        SecurityLevel.COMPROMISED -> DangerRed
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SUPER AI",
                                fontWeight = FontWeight.Black,
                                fontSize = 18.sp,
                                color = TextPrimary,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = CyberCyan.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "ARCHITECT OS",
                                    color = CyberCyan,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "Zero-Trust Autonomous Agent Engine",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary,
                            fontSize = 10.sp
                        )
                    }
                },
                actions = {
                    // Security Shield Status Pill
                    Surface(
                        color = securityBadgeColor.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .border(1.dp, securityBadgeColor.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .background(securityBadgeColor, CircleShape)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = securityLevel.name,
                                color = securityBadgeColor,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // History Button
                    IconButton(onClick = { showHistoryScreen = !showHistoryScreen }) {
                        Icon(
                            imageVector = if (showHistoryScreen) Icons.Default.Close else Icons.Default.History,
                            contentDescription = "Database History",
                            tint = if (showHistoryScreen) CyberCyan else TextSecondary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = DarkSurface,
                contentColor = TextPrimary,
                tonalElevation = 8.dp,
                modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
            ) {
                AppNavDestination.values().forEach { destination ->
                    val isSelected = !showHistoryScreen && currentDestination == destination
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            showHistoryScreen = false
                            currentDestination = destination
                        },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) destination.selectedIcon else destination.unselectedIcon,
                                contentDescription = destination.title
                            )
                        },
                        label = {
                            Text(
                                text = destination.title,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFF00363A),
                            selectedTextColor = CyberCyan,
                            indicatorColor = CyberCyan,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted
                        )
                    )
                }
            }
        },
        containerColor = DarkBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (showHistoryScreen) {
                HistoryScreen(viewModel = viewModel)
            } else {
                when (currentDestination) {
                    AppNavDestination.TEXT_STUDIO -> ContentTextStudioScreen(viewModel = viewModel)
                    AppNavDestination.MULTIMODAL -> MultiModalStudioScreen(viewModel = viewModel)
                    AppNavDestination.AGENTS -> AutonomousAgentScreen(viewModel = viewModel)
                    AppNavDestination.AUTOMATION -> DeviceAutomationScreen(viewModel = viewModel)
                    AppNavDestination.SECURITY -> SecurityBlueprintScreen(viewModel = viewModel)
                }
            }
        }
    }
}
