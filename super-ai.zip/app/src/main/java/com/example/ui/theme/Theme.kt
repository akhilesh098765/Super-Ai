package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = Color(0xFF00363A),
    primaryContainer = Color(0xFF004F55),
    onPrimaryContainer = Color(0xFF6FF6FF),
    secondary = NeonPurple,
    onSecondary = Color(0xFF38006B),
    secondaryContainer = Color(0xFF55009E),
    onSecondaryContainer = Color(0xFFE9B7FF),
    tertiary = ElectricBlue,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderHighlight,
    error = DangerRed
)

private val LightColorScheme = darkColorScheme(
    // AI Architect apps shine brightest in cyber dark mode
    primary = CyberCyan,
    onPrimary = Color(0xFF00363A),
    primaryContainer = Color(0xFF004F55),
    secondary = NeonPurple,
    tertiary = ElectricBlue,
    background = DarkBackground,
    surface = DarkSurface
)

@Composable
fun SuperAiTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
