package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.NetworkSecurityConfig
import com.example.security.SecurityLevel
import com.example.ui.SuperAiViewModel
import com.example.ui.theme.*

@Composable
fun SecurityBlueprintScreen(
    viewModel: SuperAiViewModel,
    modifier: Modifier = Modifier
) {
    var selectedSection by remember { mutableStateOf(0) } // 0: Zero-Trust Security Center, 1: Architecture & Tech Stack Blueprint

    val sections = listOf("Zero-Trust Security Center", "Architecture & Blueprint")

    Column(modifier = modifier.fillMaxSize()) {
        TabRow(
            selectedTabIndex = selectedSection,
            containerColor = DarkSurface,
            contentColor = CyberCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedSection]),
                    color = CyberCyan
                )
            }
        ) {
            sections.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSection == index,
                    onClick = { selectedSection = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (selectedSection == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        when (selectedSection) {
            0 -> ZeroTrustSecuritySection(viewModel)
            1 -> SystemArchitectureBlueprintSection()
        }
    }
}

@Composable
fun ZeroTrustSecuritySection(viewModel: SuperAiViewModel) {
    val report by viewModel.integrityReport.collectAsState()
    val cryptoInput by viewModel.cryptoInput.collectAsState()
    val encryptedOutput by viewModel.encryptedCryptoOutput.collectAsState()
    val decryptedOutput by viewModel.decryptedCryptoOutput.collectAsState()
    val keyStatus by viewModel.cryptoKeyStatus.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            // Header
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = SecurityGreen, modifier = Modifier.size(26.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Zero-Trust Security & Anti-Hacking Vault", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Real-time root/jailbreak detection, hardware-backed AES-256 GCM encryption, SSL Pinning & sandboxing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Live Device Integrity Card
        report?.let { audit ->
            item {
                val statusColor = when (audit.overallSecurityLevel) {
                    SecurityLevel.SECURE -> SecurityGreen
                    SecurityLevel.SUSPICIOUS -> WarningAmber
                    SecurityLevel.COMPROMISED -> DangerRed
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, statusColor, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Play Integrity & Anti-Root Audit", fontWeight = FontWeight.Bold, color = TextPrimary)
                            Surface(
                                color = statusColor.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = audit.overallSecurityLevel.name,
                                    color = statusColor,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Divider(color = BorderHighlight, modifier = Modifier.padding(vertical = 10.dp))

                        Text("• Root / Jailbreak Status: ${if (audit.isRooted) "COMPROMISED" else "CLEAN (Unrooted)"}", color = if (audit.isRooted) DangerRed else SecurityGreen, fontSize = 13.sp)
                        Text("• Su Binaries in File System: ${if (audit.isSuBinaryFound) "DETECTED" else "NONE FOUND"}", color = if (audit.isSuBinaryFound) DangerRed else SecurityGreen, fontSize = 13.sp)
                        Text("• Test-Keys Build Tags: ${if (audit.isTestKeysDetected) "PRESENT (Development ROM)" else "OFFICIAL RELEASE KEYS"}", color = if (audit.isTestKeysDetected) WarningAmber else SecurityGreen, fontSize = 13.sp)
                        Text("• Play Integrity API Evaluation: ${audit.playIntegrityVerdict}", color = CyberCyan, fontSize = 12.sp)

                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.runSecurityAudit() },
                            colors = ButtonDefaults.buttonColors(containerColor = DarkSurface, contentColor = CyberCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Re-Run Integrity & Tamper Scan", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // AES-256 Hardware Keystore Lab
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.VpnKey, contentDescription = null, tint = CyberCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AES-256-GCM Hardware Keystore Vault", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Text(keyStatus, color = TextSecondary, fontSize = 11.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = cryptoInput,
                        onValueChange = { viewModel.cryptoInput.value = it },
                        label = { Text("Plaintext to Encrypt", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = BorderHighlight,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = DarkSurface,
                            unfocusedContainerColor = DarkSurface
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { viewModel.testCryptoEncrypt() },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF00363A)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Encrypt (AES-256)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { viewModel.testCryptoDecrypt() },
                            enabled = encryptedOutput.isNotBlank(),
                            colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Decrypt", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    if (encryptedOutput.isNotBlank()) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Ciphertext (IV:Ciphertext):", style = MaterialTheme.typography.labelSmall, color = CyberCyan)
                        Surface(
                            color = DarkBackground,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = encryptedOutput,
                                color = TextSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (decryptedOutput.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Decrypted Plaintext:", style = MaterialTheme.typography.labelSmall, color = SecurityGreen)
                        Surface(
                            color = DarkBackground,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = decryptedOutput,
                                color = SecurityGreen,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        // SSL Pinning & TLS 1.3 Specification Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = CyberCyan)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("TLS 1.3 & SSL Pinning Enforcement", fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Strict SHA-256 certificate pinning prevents Man-in-the-Middle (MitM) proxies (Charles, Burp Suite, Wireshark).",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    NetworkSecurityConfig.getSslPinningManifest().forEach { (domain, pin) ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(domain, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(pin.take(18) + "...", color = CyberCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SystemArchitectureBlueprintSection() {
    val scrollState = rememberScrollState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountTree, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(26.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Enterprise Super AI Architecture Blueprint", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Complete end-to-end system design covering Mobile App, Backend, AI Engines, and Security Sandboxing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Architecture Flow Diagram Box
        item {
            Text("System Architecture Flow (Mermaid & ASCII)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = CyberCyan)
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                color = DarkBackground,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier
                        .padding(12.dp)
                        .horizontalScroll(scrollState)
                ) {
                    val asciiDiagram = """
┌────────────────────────────────────────────────────────────────────────┐
│                   SUPER AI MOBILE APP (Client Layer)                   │
├────────────────────────────────────────────────────────────────────────┤
│  [UI Layer: Jetpack Compose / Flutter / React Native M3 Shell]         │
│  ├── Content & Text Studio (Generation, Paraphrase, Plagiarism)        │
│  ├── Multi-Modal Studio (ElevenLabs/TTS, Imagen 3, Veo/Runway)         │
│  ├── Autonomous Agent Engine (CrewAI/LangChain Orchestrator)           │
│  └── Zero-Trust Security Dashboard & Device Actuators                  │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │
                 ┌─────────────────┴─────────────────┐
                 │ ZERO-TRUST SECURITY & BRIDGE      │
                 ├───────────────────────────────────┤
                 │ • TLS 1.3 + SSL Certificate Pin   │
                 │ • AndroidKeyStore AES-256 GCM     │
                 │ • Biometric / PIN Auth Gate       │
                 │ • Play Integrity / Root Detection │
                 │ • Accessibility Service Actuators │
                 └─────────────────┬─────────────────┘
                                   │
            ┌──────────────────────┴──────────────────────┐
            ▼                                             ▼
┌───────────────────────────────┐             ┌─────────────────────────┐
│ BACKEND & API GATEWAY         │             │ CLOUD & MODEL SERVICES  │
├───────────────────────────────┤             ├─────────────────────────┤
│ • Serverless Edge (Node.js/Go)│             │ • Google Gemini 3.5/Pro │
│ • OAuth 2.0 / OIDC + Short JWT│             │ • Imagen 3 / Midjourney │
│ • Redis Token & Task Cache    │             │ • ElevenLabs Voice API  │
│ • Spanner / Postgres (Encrypted)            │ • Veo / Runway Gen-2    │
└───────────────────────────────┘             └─────────────────────────┘
                    """.trimIndent()

                    Text(
                        text = asciiDiagram,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = CyberCyan,
                        lineHeight = 15.sp
                    )
                }
            }
        }

        // Tech Stack Recommendation
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Production Tech Stack Recommendation", fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleSmall)
                    Divider(color = BorderHighlight, modifier = Modifier.padding(vertical = 8.dp))

                    Text("1. Mobile Frontend: Kotlin Jetpack Compose (Native Android) / Flutter (Cross-platform)", color = CyberCyan, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("• Local DB: Room (SQLite) with SQLCipher AES-256 encryption", color = TextSecondary, fontSize = 12.sp)
                    Text("• Network: Retrofit / OkHttp with CertificatePinner & TLS 1.3", color = TextSecondary, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("2. Backend & Microservices: Node.js (NestJS / TypeScript) or Go Gin", color = NeonPurple, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("• API Gateway: Envoy / Kong with Cloudflare zero-trust DDoS protection", color = TextSecondary, fontSize = 12.sp)
                    Text("• Auth: OAuth 2.0 + OIDC, Firebase Auth / Auth0, Biometric Credential Manager", color = TextSecondary, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("3. AI Agent Frameworks & Models:", color = ElectricBlue, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("• Reasoning & Text: Google Gemini 3.5 Flash & Gemini 3.1 Pro", color = TextSecondary, fontSize = 12.sp)
                    Text("• Audio Synthesis: ElevenLabs Neural Voice API / Google Cloud TTS", color = TextSecondary, fontSize = 12.sp)
                    Text("• Visuals: Imagen 3 / Stable Diffusion XL via REST endpoint", color = TextSecondary, fontSize = 12.sp)
                    Text("• Video: Veo 3.1 / Runway Gen-2 async video generation pipeline", color = TextSecondary, fontSize = 12.sp)
                    Text("• Orchestration: CrewAI / LangChain DAG workflow engine", color = TextSecondary, fontSize = 12.sp)
                }
            }
        }

        // Play Store / App Store Compliance Guide
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(14.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Security & App Store Compliance Checklist", fontWeight = FontWeight.Bold, color = SecurityGreen, style = MaterialTheme.typography.titleSmall)
                    Divider(color = BorderHighlight, modifier = Modifier.padding(vertical = 8.dp))

                    Text("✓ Accessibility Service Disclosure: Prominently explain to user exactly why Accessibility is requested (for automated assistive actions), with opt-in consent and zero data extraction.", color = TextPrimary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("✓ ProGuard / R8 Obfuscation: Strip debug logs, obscure class/method names, and protect against dex decompilation.", color = TextPrimary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("✓ Play Integrity API: Implement device integrity token attestation on server before dispatching high-risk AI agent payloads.", color = TextPrimary, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("✓ Zero Hardcoded Secrets: All API keys stored server-side behind authenticated proxy or injected securely via Secrets Gradle Plugin / NDK JNI layer.", color = TextPrimary, fontSize = 12.sp)
                }
            }
        }
    }
}
