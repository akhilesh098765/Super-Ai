package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber AI Theme Colors
val CyberCyan = Color(0xFF00F0FF)
val CyberCyanMuted = Color(0xFF00A3AD)
val DeepViolet = Color(0xFF7B2CBF)
val NeonPurple = Color(0xFF9D4EDD)
val ElectricBlue = Color(0xFF3A86FF)

val DarkBackground = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF131A29)
val DarkSurfaceVariant = Color(0xFF1C2438)
val DarkCard = Color(0xFF172033)
val BorderHighlight = Color(0xFF2A3655)

val SecurityGreen = Color(0xFF00E676)
val SecurityGreenBg = Color(0xFF0A2E1C)
val WarningAmber = Color(0xFFFFB703)
val DangerRed = Color(0xFFFF3366)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
