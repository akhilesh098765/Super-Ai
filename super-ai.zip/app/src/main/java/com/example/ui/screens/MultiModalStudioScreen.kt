package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.SuperAiViewModel
import com.example.ui.theme.*

@Composable
fun MultiModalStudioScreen(
    viewModel: SuperAiViewModel,
    modifier: Modifier = Modifier
) {
    var activeSubTab by remember { mutableStateOf(0) } // 0: Audio TTS, 1: Image Gen, 2: Video Gen

    val subTabs = listOf("Audio / Voice TTS", "Text-to-Image", "Text-to-Video")

    Column(modifier = modifier.fillMaxSize()) {
        // Sub-Tab Navigation Bar
        TabRow(
            selectedTabIndex = activeSubTab,
            containerColor = DarkSurface,
            contentColor = CyberCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[activeSubTab]),
                    color = CyberCyan
                )
            }
        ) {
            subTabs.forEachIndexed { index, title ->
                Tab(
                    selected = activeSubTab == index,
                    onClick = { activeSubTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = if (activeSubTab == index) FontWeight.Bold else FontWeight.Normal,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        when (activeSubTab) {
            0 -> AudioVoiceTtsSection(viewModel)
            1 -> ImageGenerationSection(viewModel)
            2 -> VideoGenerationSection(viewModel)
        }
    }
}

@Composable
fun AudioVoiceTtsSection(viewModel: SuperAiViewModel) {
    val ttsText by viewModel.ttsText.collectAsState()
    val isSpeaking by viewModel.ttsAudioEngine.isSpeaking.collectAsState()
    val statusMsg by viewModel.ttsAudioEngine.statusMessage.collectAsState()
    val pitch by viewModel.voicePitch.collectAsState()
    val speed by viewModel.voiceSpeed.collectAsState()
    val selectedVoice by viewModel.selectedVoice.collectAsState()

    val voices = listOf("Rachel (ElevenLabs)", "Adam (Deep Tone)", "Kore (Google TTS)", "Aoede (Studio)")

    // Animated waveform bars
    val infiniteTransition = rememberInfiniteTransition(label = "audioWave")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveAnim"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = NeonPurple, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Voice Synthesis Engine (ElevenLabs / Google TTS)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Real-time neural text-to-speech with pitch, speed, and timbre controls.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }

        item {
            Text("Select Voice Timbre", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(voices) { voice ->
                    val isSelected = voice == selectedVoice
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectedVoice.value = voice },
                        label = { Text(voice, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NeonPurple.copy(alpha = 0.25f),
                            selectedLabelColor = NeonPurple,
                            containerColor = DarkSurfaceVariant,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = ttsText,
                onValueChange = { viewModel.ttsText.value = it },
                label = { Text("Text for Speech Synthesis", color = TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = NeonPurple,
                    unfocusedBorderColor = BorderHighlight,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            // Pitch and Speed sliders
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Pitch Control", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        Text(String.format("%.1fx", pitch), color = CyberCyan, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = pitch,
                        onValueChange = { viewModel.voicePitch.value = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Speech Speed", style = MaterialTheme.typography.labelMedium, color = TextPrimary)
                        Text(String.format("%.1fx", speed), color = NeonPurple, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = speed,
                        onValueChange = { viewModel.voiceSpeed.value = it },
                        valueRange = 0.5f..2.0f,
                        colors = SliderDefaults.colors(thumbColor = NeonPurple, activeTrackColor = NeonPurple)
                    )
                }
            }
        }

        item {
            // Audio Wave Visualizer Box
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF070B12)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp)
                    .border(1.dp, BorderHighlight, RoundedCornerShape(12.dp))
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Canvas(modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 12.dp)) {
                        val barCount = 28
                        val barWidth = size.width / (barCount * 1.5f)
                        for (i in 0 until barCount) {
                            val activeHeight = if (isSpeaking) {
                                val factor = ((Math.sin((i.toDouble() + wavePhase * 10)) + 1) / 2).toFloat()
                                size.height * (0.2f + factor * 0.7f)
                            } else {
                                size.height * 0.15f
                            }
                            val x = i * (barWidth * 1.5f)
                            val y = (size.height - activeHeight) / 2
                            drawRoundRect(
                                color = if (isSpeaking) NeonPurple else BorderHighlight,
                                topLeft = Offset(x, y),
                                size = androidx.compose.ui.geometry.Size(barWidth, activeHeight),
                                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                            )
                        }
                    }
                }
            }
        }

        item {
            // Controls
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = { viewModel.speakText() },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPurple),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Synthesize & Play", fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { viewModel.stopSpeaking() },
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = DangerRed),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(DangerRed))
                ) {
                    Icon(Icons.Default.Stop, contentDescription = null)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Stop")
                }
            }
        }

        item {
            Text(text = "Status: $statusMsg", style = MaterialTheme.typography.bodySmall, color = TextMuted)
        }
    }
}

@Composable
fun ImageGenerationSection(viewModel: SuperAiViewModel) {
    val prompt by viewModel.imagePrompt.collectAsState()
    val selectedStyle by viewModel.selectedImageStyle.collectAsState()
    val selectedAspect by viewModel.selectedAspectRatio.collectAsState()
    val isGenerating by viewModel.isGeneratingImage.collectAsState()
    val generatedInfo by viewModel.generatedImageInfo.collectAsState()

    val styles = listOf("Cyberpunk", "Photorealistic", "Cinematic 3D", "Anime Neon", "Oil Painting")
    val aspectRatios = listOf("1:1", "16:9", "9:16", "4:3")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Palette, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Image & Graphic Generation (Imagen 3 / Midjourney)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Prompt engineering, aspect ratio composition, and style embeddings.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }

        item {
            Text("Artistic Style Filter", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(styles) { style ->
                    val isSelected = style == selectedStyle
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectedImageStyle.value = style },
                        label = { Text(style, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                            selectedLabelColor = CyberCyan,
                            containerColor = DarkSurfaceVariant,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        item {
            Text("Aspect Ratio", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
            Spacer(modifier = Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                aspectRatios.forEach { ratio ->
                    val isSelected = ratio == selectedAspect
                    OutlinedButton(
                        onClick = { viewModel.selectedAspectRatio.value = ratio },
                        colors = ButtonDefaults.outlinedButtonColors(
                            containerColor = if (isSelected) CyberCyan.copy(alpha = 0.15f) else Color.Transparent,
                            contentColor = if (isSelected) CyberCyan else TextSecondary
                        ),
                        border = ButtonDefaults.outlinedButtonBorder.copy(
                            brush = androidx.compose.ui.graphics.SolidColor(if (isSelected) CyberCyan else BorderHighlight)
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(ratio, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = prompt,
                onValueChange = { viewModel.imagePrompt.value = it },
                label = { Text("Image Description / Visual Prompt", color = TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = BorderHighlight,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Button(
                onClick = { viewModel.generateImage() },
                enabled = !isGenerating && prompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF00363A)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color(0xFF00363A), strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Brush, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Render Visual Artwork (4K)", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (generatedInfo.isNotBlank()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberCyan, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SecurityGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Artwork Synthesized Successfully", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = generatedInfo, style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                    }
                }
            }
        }
    }
}

@Composable
fun VideoGenerationSection(viewModel: SuperAiViewModel) {
    val prompt by viewModel.videoPrompt.collectAsState()
    val selectedCamera by viewModel.selectedCameraMotion.collectAsState()
    val isGenerating by viewModel.isGeneratingVideo.collectAsState()
    val generatedInfo by viewModel.generatedVideoInfo.collectAsState()

    val motions = listOf("Orbit 360", "Dynamic Pan", "Zoom In", "FPV Drone Push")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Text-to-Video Engine (Veo / Runway Gen-2)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Generate cinematic 60fps video clips with camera movement controls & scene storyboards.", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                }
            }
        }

        item {
            Text("Camera Trajectory", style = MaterialTheme.typography.labelMedium, color = ElectricBlue)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(motions) { motion ->
                    val isSelected = motion == selectedCamera
                    FilterChip(
                        selected = isSelected,
                        onClick = { viewModel.selectedCameraMotion.value = motion },
                        label = { Text(motion, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ElectricBlue.copy(alpha = 0.25f),
                            selectedLabelColor = ElectricBlue,
                            containerColor = DarkSurfaceVariant,
                            labelColor = TextSecondary
                        )
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = prompt,
                onValueChange = { viewModel.videoPrompt.value = it },
                label = { Text("Video Prompt & Scene Direction", color = TextSecondary) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 5,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = ElectricBlue,
                    unfocusedBorderColor = BorderHighlight,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            Button(
                onClick = { viewModel.generateVideo() },
                enabled = !isGenerating && prompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                } else {
                    Icon(Icons.Default.Movie, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Generate Cinematic Video Storyboard", fontWeight = FontWeight.Bold)
                }
            }
        }

        if (generatedInfo.isNotBlank()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, ElectricBlue, RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, tint = ElectricBlue)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Video Pipeline & Frame Decomposition", fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Divider(color = BorderHighlight, modifier = Modifier.padding(vertical = 8.dp))
                        Text(text = generatedInfo, style = MaterialTheme.typography.bodySmall, color = TextPrimary, lineHeight = 20.sp)
                    }
                }
            }
        }
    }
}
