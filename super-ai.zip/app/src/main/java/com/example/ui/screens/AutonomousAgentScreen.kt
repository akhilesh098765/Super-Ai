package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentRole
import com.example.agent.TaskStatus
import com.example.ui.SuperAiViewModel
import com.example.ui.theme.*

@Composable
fun AutonomousAgentScreen(
    viewModel: SuperAiViewModel,
    modifier: Modifier = Modifier
) {
    val goalInput by viewModel.agentGoalInput.collectAsState()
    val agentState by viewModel.agentExecutionState.collectAsState()

    val presets = listOf(
        "Analyze competitor cybersecurity posture & extract weaknesses",
        "Automate system file sanitization and generate audit logs",
        "Formulate full-stack multi-agent mobile architecture blueprint"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 96.dp)
    ) {
        item {
            // Header card
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, BorderHighlight, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(26.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Autonomous Multi-Agent Swarm", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Goal decomposition, tool use, CrewAI & LangChain orchestration with automated self-reflection.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        item {
            // Preset Goals
            Text("Quick Strategic Objectives", style = MaterialTheme.typography.labelMedium, color = CyberCyan)
            Spacer(modifier = Modifier.height(6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(presets) { preset ->
                    SuggestionChip(
                        onClick = { viewModel.agentGoalInput.value = preset },
                        label = { Text(preset.take(32) + "...", fontSize = 11.sp, maxLines = 1) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = DarkSurfaceVariant,
                            labelColor = TextSecondary
                        ),
                        border = SuggestionChipDefaults.suggestionChipBorder(
                            borderColor = BorderHighlight,
                            enabled = true
                        )
                    )
                }
            }
        }

        item {
            OutlinedTextField(
                value = goalInput,
                onValueChange = { viewModel.agentGoalInput.value = it },
                label = { Text("High-Level Goal / Objective", color = TextSecondary) },
                placeholder = { Text("Describe what the agent should accomplish...", color = TextMuted) },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = BorderHighlight,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface
                ),
                shape = RoundedCornerShape(12.dp)
            )
        }

        item {
            val isRunning = agentState?.isRunning == true
            Button(
                onClick = { viewModel.runAgentWorkflow() },
                enabled = !isRunning && goalInput.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = Color(0xFF00363A)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                if (isRunning) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color(0xFF00363A), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Agents Decomposing & Executing...", fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Decompose & Execute Goal", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Display Active Tasks / Subtask execution pipeline
        agentState?.let { state ->
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Hierarchical Execution Graph", fontWeight = FontWeight.Bold, color = TextPrimary, style = MaterialTheme.typography.titleSmall)
                    Text(
                        text = if (state.isRunning) "Status: EXECUTING" else "Status: COMPLETED",
                        color = if (state.isRunning) WarningAmber else SecurityGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }

            items(state.tasks) { task ->
                val badgeColor = Color(task.role.badgeColorHex)
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            if (task.status == TaskStatus.RUNNING) CyberCyan else BorderHighlight,
                            RoundedCornerShape(12.dp)
                        )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                color = badgeColor.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = task.role.displayName,
                                    color = badgeColor,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }

                            when (task.status) {
                                TaskStatus.PENDING -> Text("PENDING", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                TaskStatus.RUNNING -> Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(modifier = Modifier.size(12.dp), strokeWidth = 2.dp, color = CyberCyan)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("RUNNING", color = CyberCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                TaskStatus.COMPLETED -> Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SecurityGreen, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("DONE", color = SecurityGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                TaskStatus.FAILED -> Text("FAILED", color = DangerRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(task.title, fontWeight = FontWeight.SemiBold, color = TextPrimary, fontSize = 14.sp)

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Tool: ${task.toolName}", color = TextSecondary, fontSize = 12.sp)

                        if (task.outputResult.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Surface(
                                color = DarkBackground,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text("Output: ${task.outputResult}", color = TextPrimary, fontSize = 12.sp)
                                    if (task.reflectionNote.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text("Self-Reflection: ${task.reflectionNote}", color = WarningAmber, fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (state.finalSynthesis.isNotBlank()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = SecurityGreenBg),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SecurityGreen, RoundedCornerShape(14.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = SecurityGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Final Swarm Synthesis & Reflection", fontWeight = FontWeight.Bold, color = SecurityGreen)
                            }
                            Divider(color = SecurityGreen.copy(alpha = 0.3f), modifier = Modifier.padding(vertical = 8.dp))
                            Text(text = state.finalSynthesis, color = TextPrimary, fontSize = 13.sp, lineHeight = 20.sp)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(text = "Critic Verdict: ${state.selfReflectionCritique}", color = WarningAmber, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
