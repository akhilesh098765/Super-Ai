package com.example.security

import android.content.Context
import android.os.Build
import java.io.File

data class IntegrityCheckResult(
    val isRooted: Boolean,
    val isTestKeysDetected: Boolean,
    val isSuBinaryFound: Boolean,
    val isBusyboxFound: Boolean,
    val suspiciousPaths: List<String>,
    val playIntegrityVerdict: String,
    val overallSecurityLevel: SecurityLevel
)

enum class SecurityLevel {
    SECURE,
    SUSPICIOUS,
    COMPROMISED
}

object DeviceIntegrityChecker {

    private val SU_PATHS = arrayOf(
        "/system/app/Superuser.apk",
        "/sbin/su",
        "/system/bin/su",
        "/system/xbin/su",
        "/data/local/xbin/su",
        "/data/local/bin/su",
        "/system/sd/xbin/su",
        "/system/bin/failsafe/su",
        "/data/local/su",
        "/su/bin/su"
    )

    private val BUSYBOX_PATHS = arrayOf(
        "/system/xbin/busybox",
        "/system/bin/busybox",
        "/sbin/busybox"
    )

    fun performIntegrityAudit(context: Context): IntegrityCheckResult {
        // 1. Build Tags check
        val buildTags = Build.TAGS
        val hasTestKeys = buildTags != null && buildTags.contains("test-keys")

        // 2. Su binaries detection
        val foundSuPaths = mutableListOf<String>()
        for (path in SU_PATHS) {
            try {
                val file = File(path)
                if (file.exists()) {
                    foundSuPaths.add(path)
                }
            } catch (_: Exception) {}
        }

        // 3. BusyBox detection
        var busyboxFound = false
        for (path in BUSYBOX_PATHS) {
            try {
                if (File(path).exists()) {
                    busyboxFound = true
                    foundSuPaths.add(path)
                }
            } catch (_: Exception) {}
        }

        val isRooted = hasTestKeys || foundSuPaths.isNotEmpty() || busyboxFound

        val verdict = when {
            foundSuPaths.isNotEmpty() -> "PLAY_INTEGRITY_FAIL_UNTRUSTED_DEVICE"
            hasTestKeys -> "PLAY_INTEGRITY_BASIC_INTEGRITY_ONLY"
            else -> "PLAY_INTEGRITY_MEETS_STRONG_INTEGRITY"
        }

        val securityLevel = when {
            foundSuPaths.isNotEmpty() -> SecurityLevel.COMPROMISED
            hasTestKeys -> SecurityLevel.SUSPICIOUS
            else -> SecurityLevel.SECURE
        }

        return IntegrityCheckResult(
            isRooted = isRooted,
            isTestKeysDetected = hasTestKeys,
            isSuBinaryFound = foundSuPaths.isNotEmpty(),
            isBusyboxFound = busyboxFound,
            suspiciousPaths = foundSuPaths,
            playIntegrityVerdict = verdict,
            overallSecurityLevel = securityLevel
        )
    }
}
