package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "history_records")
data class HistoryItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val module: String, // TEXT, AUDIO, IMAGE, VIDEO, AGENT, AUTOMATION, SECURITY
    val title: String,
    val prompt: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)
